import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Button } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';


const FormRow = ({ label, value, onChangeText, onButtonPress, showButton = true, keyboardType, secureTextEntry = false, icon = "center-focus-weak", isActive  }) => {
  const [isFocused, setIsFocused] = useState(false);
  return (
    <View style={styles.rowContainer}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChangeText}
        placeholder={`请输入${label}`}
        keyboardType={keyboardType || 'default'}
        secureTextEntry={secureTextEntry}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        style={[styles.input, isFocused && styles.inputFocused]}
      />
      {showButton && (
        <TouchableOpacity
                onPress={onButtonPress}
                style={[
                  styles.button,
                  isActive && styles.activeButton // 条件样式
                ]}
              >
                <Icon
                  name={icon}
                  size={24}
                  color={isActive ? '#4ae879' : '#666'}
                />
              </TouchableOpacity>
      )}
    </View>
  );
};