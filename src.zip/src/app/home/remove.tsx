import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Button } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

// 可复用的表单项组件
const FormRow = ({ label, value, onChangeText, onButtonPress, showButton = true, keyboardType, secureTextEntry = false, icon = "center-focus-weak", isActive  }) => {
  const [isFocused, setIsFocused] = useState(false);
  return (
    <View style={styles.rowContainer}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChangeText}
        placeholder={`请输入${label}`}
        keyboardType={keyboardType || 'default'}
        secureTextEntry={secureTextEntry}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        style={[styles.input, isFocused && styles.inputFocused]}
      />
      {showButton && (
        <TouchableOpacity
          onPress={onButtonPress}
          style={[
            styles.button,
            isActive && styles.activeButton // 条件样式
          ]}
        >
          <Icon
            name={icon}
            size={24}
            color={isActive ? '#4ae879' : '#666'}
          />
        </TouchableOpacity>
      )}
    </View>
  );
};

const App = () => {
  const [formData, setFormData] = useState({
    shelve: {value: "123", active: false},
    work: {value: "", active: false}
  });

  const [activeField, setField] = useState({
    fieldName: ""
  })


  // 示例按钮操作：日期选择
  const handleSelectBirthday = () => {
    // 这里可以接入日期选择组件（如：react-native-date-picker）
    console.log('打开日期选择器');
  };

  const handleButtonPress = (fieldName) => {
      if(fieldName == activeField.fieldName){
          setFormData(prev => ({
            ...prev,
            [fieldName]: {
              value:"",
              active: !prev[fieldName].active // 切换激活状态
            }
          }));
          setField(prev => (
            {
                ...prev,
                fieldName:""
                }
          ))
      }else{
        setFormData(prev => ({
          ...prev, // 保留其他字段不变
          shelve: {
            ...prev.shelve, // 保留 birthday 的其他属性
            active: false // 只修改 active 属性
          },
          work: {
            ...prev.work,
            active: false
          }
        }));
        // 扫码处理后传递结果
        setFormData(prev => ({
           ...prev,
           [fieldName]: {
             value:"聚焦在这里",
             active: !prev[fieldName].active // 切换激活状态
           }
         }));
         setField(prev => (
           {
               ...prev,
               fieldName:fieldName
               }
         ))
      }

    };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <FormRow
        label="货架编号"
        value={formData.shelve.value}
        onChangeText={(text) => setFormData({ ...formData, shelve: text })}
        isActive={formData.shelve.active}
        onButtonPress={() => handleButtonPress('shelve')}
      />

      <FormRow
        label="工位编码"
        value={formData.work.value}
        onChangeText={(text) => setFormData({ ...formData, work: text })}
        onButtonPress={() => handleButtonPress('work')}
        isActive={formData.work.active}
      />
      <Button title="确定"
                color="#5af07e">
      </Button>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#fff'
  },
  rowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    paddingVertical: 12,
  },
  label: {
    width: 80,
    fontSize: 16,
    color: '#333',
    marginRight: 8
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#333',
    paddingVertical: 8,
    paddingRight: 8
  },
  button: {
    padding: 8,
    marginLeft: 8
  }
});

export default App;