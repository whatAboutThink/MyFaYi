import React, { Component } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
} from 'react-native';

class checkComponet extends React.Component{
        render() {
                return (
                    <View>
                        <Text>我是补货</Text>
                    </View>
                    )
            }
    }

export default checkComponet;