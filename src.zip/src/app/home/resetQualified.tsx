import React from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
} from 'react-native';

class unqualified extends React.Component{
        render() {
                return (
                    <View>
                        <Text>我是重登记合格</Text>
                    </View>
                    )
            }
    }

export default unqualified;